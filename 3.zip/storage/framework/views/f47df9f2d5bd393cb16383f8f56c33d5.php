<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
    <div>
        <div class="row">
            <div class="col">
                <h1 class="font-weight-bold">Data pengguna</h1>
                <a class="btn btn-primary" href="<?php echo e(url('dashboard/add-user')); ?>">Tambah pengguna</a>
            </div>
            <div class="col">
                <h4 class="font-weight-bold">Halo,
                    <?php echo e(Auth::user()->email); ?>

                </h4>
                <a class="btn btn-danger" href="<?php echo e(route('logout')); ?>">Logout</a>
            </div>
        </div>

        <table class="table">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Aksi</th>
                    <th scope="col">Avatar</th>
                    <th scope="col">Nama</th>
                    <th scope="col">Email</th>
                    <th scope="col">Phone</th>
                    <th scope="col">Role</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $no = 1;
                ?>
                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td scope="row">
                            <?php echo e($no++); ?>

                        </td>
                        <td>
                            <div class="btn-group" role="group" aria-label="Basic example">
                                <a href="detail.php?id=<?php echo e($d['id']); ?>" class="btn btn-primary">Detail</a>
                                <a href="<?php echo e(url('dashboard/edit-user/' . $d['id'])); ?>" class="btn btn-warning">Edit</a>
                                <a href="<?php echo e(url('dashboard/delete-user/' . $d['id'])); ?>" class="btn btn-danger">Hapus</a>
                            </div>
                        </td>
                        <td>
                            <img class="rounded-circle" style="height: 50px; width: 50px" src="<?php echo e(asset($d['avatar'])); ?>"
                                alt="Avatar">
                        </td>
                        <td>
                            <?php echo e($d['name']); ?>

                        </td>
                        <td>
                            <?php echo e($d['email']); ?>

                        </td>
                        <td>
                            <?php echo e($d['phone']); ?>

                        </td>
                        <td>
                            <?php echo e($d['role']); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard/dashboard-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/wahyu/Documents/Joki/+62 895-3030-0252/laravel-full/3/resources/views/dashboard/index.blade.php ENDPATH**/ ?>