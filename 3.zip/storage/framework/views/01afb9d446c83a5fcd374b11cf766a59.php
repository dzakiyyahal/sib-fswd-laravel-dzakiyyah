<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
    <div>
        <h1 class="font-weight-bold">Tambah pengguna</h1>
        <a class="btn btn-primary" href="<?php echo e(url('/')); ?>">Kembali</a>

        <form action="<?php echo e(url('add-user')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label>Nama</label>
                <input name="name" type="text" placeholder="Nama lengkap" class="form-control">
            </div>
            <div class="row">
                <div class="col form-group">
                    <label>Role</label>
                    <select name="role" class="form-control">
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($role['name']); ?>">
                                <?php echo e($role['name']); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col form-group">
                    <label>Password</label>
                    <input name="password" type="password" placeholder="Password" class="form-control">
                </div>
            </div>
            <div class="row">
                <div class="col form-group">
                    <label>Email</label>
                    <input name="email" type="email" placeholder="Email" class="form-control">
                </div>
                <div class="col form-group">
                    <label>Telp</label>
                    <input name="phone" type="number" placeholder="Telp" class="form-control">
                </div>
            </div>
            <div class="form-group">
                <label>Alamat lengkap</label>
                <textarea name="address" class="form-control" rows="3"></textarea>
            </div>
            <div class="form-group">
                <label>Unggah foto</label>
                <input name="avatar" type="file" class="form-control-file">
            </div>

            <input type="submit" class="btn btn-primary" value="Submit">
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/wahyu/Documents/Joki/+62 895-3030-0252/laravel-full/3/resources/views/create.blade.php ENDPATH**/ ?>