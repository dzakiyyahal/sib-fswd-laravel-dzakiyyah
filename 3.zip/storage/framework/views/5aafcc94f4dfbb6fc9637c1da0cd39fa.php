<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
    <div>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <h1 class="font-weight-bold">Login</h1>

        <form action="<?php echo e(url('login')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label>Email</label>
                <input name="email" type="text" placeholder="Email" class="form-control">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input name="password" type="password" placeholder="Password" class="form-control-file">
            </div>

            <input type="submit" class="btn btn-primary" value="Submit">
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/wahyu/Documents/Joki/+62 895-3030-0252/laravel-full/3/resources/views/login.blade.php ENDPATH**/ ?>